class SearchPageClass < BasePageClass

  text_field :search, :name => "q"

end